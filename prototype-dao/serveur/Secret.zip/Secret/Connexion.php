<?php

class Connexion
{
    public static function initialiser()
    {
        $usager = 'maya';
        $motdepasse = 'iju8$#df';
        $hote = 'localhost';
        $base = 'lieux';
        $dsn = "mysql:host=$hote;dbname=$base;";
        $basededonnees = new PDO($dsn, $usager, $motdepasse);
        $basededonnees->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $basededonnees;
    }
}